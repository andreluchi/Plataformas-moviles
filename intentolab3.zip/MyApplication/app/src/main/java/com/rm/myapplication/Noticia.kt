package com.rm.myapplication

data class Noticia (
    var title: String,
    var image: String
)