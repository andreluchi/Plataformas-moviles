package com.rm.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

public class NoticiasAdaptador( private val listener: NewsHolder.ClickListener) :
    RecyclerView.Adapter<NoticiasAdaptador.NewsHolder>(){

    private var news: MutableList<News> = mutableListOf()



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_noticia,parent,false)
        return NewsHolder(view)
    }

    override fun onBindViewHolder(holder: NewsHolder, position: Int) {
        holder.bind(news[position], listener )
    }

    override fun getItemCount(): Int {
        return this.news.size

    }

    class NewsHolder(itemView: View) : RecyclerView.ViewHolder(itemView){

        fun bind(noticia:Noticia) = with(itemView){
            val txtTitle : TextView = findViewById(R.id.txtTitle)
            val image : ImageView = findViewById(R.id.imagen)
            txtTitle.text = noticia.title

            Picasso.get().load(noticia.image).into(image);

        }
    }
}