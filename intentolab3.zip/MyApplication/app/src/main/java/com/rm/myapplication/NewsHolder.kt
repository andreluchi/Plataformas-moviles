package com.rm.myapplication

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.item_noticia.view.*
import java.text.FieldPosition

class NewsHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
    fun bind(news: News, listener: ClickListener) = with(itemView){
        txtTitle.text = news.title
        txtDescription.text = news.description

        Picasso.get()
            .load(news.image)
            .placeholder(R.drawable.placeholder)
            .error(R.drawable.placeholder)
            .into(imageNews)

        setOnClickListener{
            listener.onItemLongClicked(adapterPosition)
        }

        setOnClickListener {
            listener.onItemLongClicked(adapterPosition)
        }

    }

    interface ClickListener{
        fun onItemClicked(position: Int)

        fun onItemLongClicked(position: Int): Boolean
    }
}